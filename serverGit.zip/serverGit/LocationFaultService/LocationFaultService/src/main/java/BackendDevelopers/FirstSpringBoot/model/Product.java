package BackendDevelopers.FirstSpringBoot.model;


public class Product {
	
	private int productID;
	
	private String productName;
	
	public Product() {
		
		super();
		System.out.println("new product created....");
		// TODO Auto-generated constructor stub
	}
	
	public Product(int productID, String productName) {
		super();
		this.productID = productID;
		this.productName = productName;
	}

	public int getProductID() {
	this.productID = productID;
		System.out.println("stored product id");
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName=" + productName + "]"+ "-" + hashCode();
	}

}
