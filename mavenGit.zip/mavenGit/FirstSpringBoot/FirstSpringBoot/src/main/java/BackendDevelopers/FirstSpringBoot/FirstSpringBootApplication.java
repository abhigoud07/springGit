package BackendDevelopers.FirstSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootApplication {
//entry point for springboot application.
	public static void main(String[] args) {
		
		//starts the tomcat server and deploys the website/application on the tomcat server.
		SpringApplication.run(FirstSpringBootApplication.class, args);
		System.out.println("started the server....");
	}

}
