package BackendDevelopers.FirstSpringBoot.service;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.dao.productslist;
import BackendDevelopers.FirstSpringBoot.model.Product;
//any class marked with @service controls concurrent or parallel
//access to dao layer , there by preventing data loss or data ambiguity or data corruption
@Service
public class ProductService {
	productslist Plist=new productslist();
	public HashMap<Integer,Product>getProductList(){
		System.out.println("getting product list");
		return Plist.getProductList();
		
		
	}
		
	public String addProduct(Product p) {
		
		System.out.println("adding product list");
		return Plist.addProduct(p);
	
	}
	public String deleteProduct(int ProductID)
	{
		System.out.println("deleting product list");
		return Plist.deleteProduct(ProductID);
	}

	public String searchbyID(int ProductID) {
		System.out.println("searching product list");
		return Plist.searchbyID(ProductID);
		
}
	public String updateProduct(int ProductID, String newProductName ) {
		System.out.println("updating product list");
		return Plist.updateProduct(ProductID, newProductName);
	}
}
