package BackendDevelopers.FirstSpringBoot.dao;

import java.util.ArrayList;

import java.util.HashMap;

import BackendDevelopers.FirstSpringBoot.model.Product;

public class productslist {
	public HashMap<Integer, Product>  productslist=new
			HashMap();
	public productslist() {
		productslist.put(1,new Product(1,"samsung Zfold"));
		productslist.put(2,new Product(2,"iphone 17 pro max"));
		productslist.put(3,new Product(3,"nexus s70"));
		productslist.put(4,new Product(4,"samsung A55"));
		System.err.println("products list reated");
	}
	public HashMap<Integer,Product>getProductList(){
		System.out.println("retrivrd product list and sent it...");
		return productslist;
		
	}
	public String addProduct(Product p) {
		productslist.put(p.getProductID(),p);
		System.out.println("Added new product");
		return"<b>Product added successfully."
				+"use /list to get updated list of products...";
	
	}
	public String deleteProduct(int ProductID)
	{
		Product p=productslist.get(ProductID);
		if (p != null) {
			productslist.remove(ProductID);
			return "<b>Product found and deleted</>&bsp;" + p;
	}else
			return "<b>Product not found</b>";
}
	public String searchbyID(int ProductID) {
		Product p=productslist.get(ProductID);
		if (p != null)
			return "<b>Product found</>&bsp;" + p;
		else
			return "<b>Product not found</b>";
}
	public String updateProduct(int ProductID, String newProductName ) {
		if (productslist.containsKey(ProductID)) {
			Product p =productslist.get(ProductID);
			p.setProductName(newProductName);
			productslist.put(p.getProductID(), p);
			System.out.println(p.toString());
		}else
				System.out.println("product not found");
			
			System.out.println("got a put request....");

			return "<b>Hello<b>";
}
}