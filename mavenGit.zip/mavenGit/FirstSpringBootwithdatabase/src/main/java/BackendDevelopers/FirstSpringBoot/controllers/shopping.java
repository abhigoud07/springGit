package BackendDevelopers.FirstSpringBoot.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;

//@RestController converts normal java class into controller
//A controller has one or more API's
@RestController
@RequestMapping("/shopping")
public class shopping {
	public long visitorcount=0;
	@Autowired
	ProductService service;
	public shopping() {
		
		System.err.println("controller created");
		
	}
		
	
	//link this API's with the browser
	//If the URL is http://localhist10000/shopping/,then call home() method and return response to the client.
	@RequestMapping(path="/",method=RequestMethod.GET)
	//call back method
	public String home() {
		visitorcount++;
		String response = "<html>< body><b>";
		response += "welcome to onlone shopping<h1><br>";
		response +=" <b>You are visitor # <b>" + visitorcount;
		response +="<body><html>";
		return response;
	}
	//if the URL ends with /list and the request type is GET, 
		//then GetProducts()method returns the list of products to the client'
	@GetMapping("/list")
	public ArrayList<Product> getProductsList(){
		System.out.println("got the request"
			);
		return service.getProductList();
		
	}
	//request param indicates that the value for productID is sent at end of the url.
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pID") int productID)
	{
		return service.searchbyID(productID);
			
		}
	
	@DeleteMapping(path="/deleteID/{pID}")
	
	
	public String deleteProduct(@PathVariable("pID")int productID) {
		System.out.println("got delete req");
	return service.deleteProduct(productID);
}
	//@postmapping is used to recover POST request from the client.
	//to read the the data use @RequestBody annotation
	@PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Product p) {
		System.out.println("got add req");
		return service.addProduct(p);
	}
	@PutMapping(path="/update", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Product p) {
		
			System.out.println("got update req");
		
		
		return service.updateProduct(p.getProductID(),p.getProductName());
	}
}
