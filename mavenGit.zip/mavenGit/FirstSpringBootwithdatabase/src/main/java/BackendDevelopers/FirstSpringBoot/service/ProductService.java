package BackendDevelopers.FirstSpringBoot.service;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.dao.productslist;
import BackendDevelopers.FirstSpringBoot.model.Product;
//any class marked with @service controls concurrent or parallel
//access to dao layer , there by preventing data loss or data ambiguity or data corruption
@Service
public class ProductService {
	@Autowired
	productslist Plist;
	public ArrayList<Product>getProductList(){
		System.out.println("getting product list");
		return (ArrayList<Product>)Plist.findAll();
		
		
	}
		
	public String addProduct(Product p) {
		
		System.out.println("adding product list");
		Product  t= Plist.save(p);
		return "<b>Added or inserted the products</b>" + t;
		
	
	}
	public String deleteProduct(int ProductID)
	{
		System.out.println("deleting product list");
		Plist.deleteById(ProductID);
		return "<b>deleted the product wih ID</b>" + ProductID;
		
	}

	public String searchbyID(int ProductID) {
		System.out.println("searching product list");
		Optional<Product> opt= Plist.findById(ProductID);
		return "Located product" + opt.get().toString();
		
}
	public String updateProduct(int ProductID, String newProductName ) {
		System.out.println("updating product list");
		Product d=new Product(ProductID, newProductName);
		return "updated product with" + Plist.save(d);
	}
}
