package BackendDevelopers.FirstSpringBoot.dao;

import java.util.ArrayList;


import java.util.HashMap;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;


import BackendDevelopers.FirstSpringBoot.model.*;
@Repository
public interface productslist extends CrudRepository <Product,Integer>{
	
		
}