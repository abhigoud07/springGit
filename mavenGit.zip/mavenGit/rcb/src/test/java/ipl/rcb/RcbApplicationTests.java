package ipl.rcb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RcbApplicationTests {

	@Test
	void contextLoads() {
	}

}
