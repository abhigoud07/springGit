package teams;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//@RestController converts normal java class into controller
//A controller has one or more API's
@RestController
@RequestMapping("/teams")
public class teamsofipl {
	public long visitorcount=0;
	public HashMap<String,String> products=new HashMap();
	public teamsofipl() {
		products.put("mi","mumbai indians");
		products.put("rcb","royal challengers banglore");
		products.put("csk","chennai super kings");
		products.put("kkr","kolkata knight riders");
		products.put("gt","gujurat titans");
		products.put("lsg","lucknow super gaints");
		products.put("srh","sun risers hydrabad");
	}
		
	
	//link this API's with the browser
	//If thr URL is http://localhist10000/shopping/,then call home() methodand return response to the client.
	@RequestMapping(path="/",method=RequestMethod.GET)
	//call back method
	public String home() {
		visitorcount++;
		String response = "<html>< body><b>";
		response += "welcome to IPL<h1><br>";
		response +=" <b>You are visitor # <b>" + visitorcount;
		response +="<body><html>";
		return response;
	}
	
		
	}

