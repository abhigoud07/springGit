package BackendDevelopers.FirstSpringBoot.service;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import BackendDevelopers.FirstSpringBoot.dao.productslist;
import BackendDevelopers.FirstSpringBoot.model.Product;
//any class marked with @service controls concurrent or parallel
//access to dao layer , there by preventing data loss or data ambiguity or data corruption
@Service
public class ProductService {
	@Autowired
	productslist Plist;
	public ArrayList<Product>getProductList(){
		System.out.println("getting product list");
		return (ArrayList<Product>)Plist.findAll();
		
		
	}
		
	public Product addProduct(Product p) {
		
		System.out.println("adding product list");
		Product  t= Plist.save(p);
		return  t;
		
	
	}
	
	
	public Product deleteProduct(int product_ID) {
	    System.out.println("Deleting Product...");

	    Optional<Product> productOpt = Plist.findById(product_ID);
	    if (productOpt.isPresent()) {
	        Product product = productOpt.get();
	        Plist.deleteById(product_ID);
	        return product;
	    } else {
	        return null; 
	    }
	}
	public List<Product> getAllProducts() {
		Iterable<Product> iterable = Plist.findAll();
		List<Product> products = new ArrayList<>();
		iterable.forEach(products::add);
		return products;

	}
		

	public String searchbyID(int ProductID) {
		System.out.println("searching product list");
		Optional<Product> opt= Plist.findById(ProductID);
		return "Located product" + opt.get().toString();
		
}
	public Product updateProduct(int ProductID, String newProductName ) {
		System.out.println("updating product list");
		Product d=new Product(ProductID, newProductName);
		return d;
	}
}
