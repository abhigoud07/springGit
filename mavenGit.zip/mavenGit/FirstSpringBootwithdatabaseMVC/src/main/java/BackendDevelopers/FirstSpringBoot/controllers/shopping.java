package BackendDevelopers.FirstSpringBoot.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;

//@RestController converts normal java class into controller
//A controller has one or more API's
@RestController
@RequestMapping("/shopping")
public class shopping {
	public long visitorcount=0;
	@Autowired
	ProductService service;
	public shopping() {
		
		System.err.println("controller created");
		
	}
		
	
	//link this API's with the browser
	//If the URL is http://localhist10000/shopping/,then call home() method and return response to the client.
	@RequestMapping(path="/",method=RequestMethod.GET)
	//call back method
	public ModelAndView home() { 
		visitorcount++;
		ModelAndView mv=new ModelAndView();
		mv.setViewName("home");
		mv.addObject("visitor",visitorcount);
		
		
		return mv;
	}
	//if the URL ends with /list and the request type is GET, 
		//then GetProducts()method returns the list of products to the client'
	@GetMapping("/list")
	public ModelAndView getProductsList(){
		ModelAndView mv= new ModelAndView();
		//Mention the name of the html file to be displayed.
		mv.setViewName("listProduct");
		mv.addObject("products",service.getProductList());
		return mv;
		
	}
	//request param indicates that the value for productID is sent at end of the url.
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pID") int productID)
	{
		return service.searchbyID(productID);
			
		}
	@GetMapping(path = "/add")
	public ModelAndView addP() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("addProduct");
		mv.addObject("Today",new java.util.Date().toString());
		visitorcount++;
		mv.addObject("vCount", visitorcount);
		return mv;
				}
	

	@PostMapping(path="/addProduct")
	public ModelAndView addProduct(@ModelAttribute Product p) {
		ModelAndView mv=new ModelAndView();
		
		System.out.println("got add req");
		Product t= service.addProduct(p);
		//name of the view(HTML page) that has to be shown in the browser.
		mv.setViewName("added.Product");
		mv.addObject("product",t);
		return mv;

	}
	@PostMapping(path="/updateProduct")
	public ModelAndView updateProduct(@ModelAttribute Product p) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("updatedProduct");
			System.out.println("got update req");
			Product t= service.updateProduct(p.getProductID(),p.getProductName());
			mv.addObject(t);

		
		return mv;
	}
	@GetMapping (path="/update")
	public ModelAndView updateP() {
		ModelAndView mv=new ModelAndView();
		
		mv.setViewName("updateProduct");
		
		return mv;
	}
	@PostMapping("/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("productID") int productID) {
	    ModelAndView mv = new ModelAndView();
	    Product product = service.deleteProduct(productID);

	    mv.setViewName("deletedProduct");
	    
	    mv.addObject("today", new java.util.Date().toString());

	    if (product != null) {
	        mv.addObject("product", product);
	    } else {
	        mv.addObject("error", "Product with ID " + productID + " not found!");
	    }

	    return mv;
	}
	@GetMapping("/delete")
	public ModelAndView showDeleteForm() {
	    ModelAndView mv = new ModelAndView();
	    mv.setViewName("deleteProduct");
	    mv.addObject("today", new java.util.Date().toString());
	    
	   
	    List<Product> products = service.getAllProducts(); 
	    mv.addObject("products", products);

	    return mv;
	}

}
